print('CODE-SENTINEL-01-open')
