def util():
    return 2


VALUE = util()
