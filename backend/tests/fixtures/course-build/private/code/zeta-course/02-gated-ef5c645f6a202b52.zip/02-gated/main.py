print('CODE-SENTINEL-02-gated')
print('three')
