print('CODE-SENTINEL-03-sealed')
print('two')
